# DOCUMENTATION UTILISATEUR  
## INFORMATON
- Nom_Fichier
- Auteur
- Date
- descrition brève du code  

*Description du programme: Nostrud consequat adipisicing minim enim dolor non commodo magna aute laboris deserunt aute. Exercitation in sint ipsum amet aliqua aute laborum fugiat commodo adipisicing enim elit duis. Ex do ex veniam voluptate laboris irure minim. Tempor velit nulla eiusmod qui irure amet consequat qui mollit aliquip pariatur reprehenderit pariatur. Pariatur minim aliqua id minim. Est est cillum sit quis deserunt ullamco officia veniam et aliquip id excepteur occaecat irure.*  

|DEFINE|Valeur| Commentaire |
|-|-|-|
| Define1 | Val1 | commentaire qui décris le define |
| Define2 | Val2 | commentaire qui décris le define |
| Define3 | Val3 | commentaire qui décris le define |
| Define4 | Val4 | commentaire qui décris le define |

### STRUCTURE  
- je_suis : int
- beau : int
- intelligent : char
- brefparfait : char

### FONCTION  
#### description de la fonction : cette fonction fait très bien son travail  
**entré :**  je fais   
**sortie :**  très bien mon travail  

### PROCÉDURE
#### description de la procédure : cette procédure travail 
**entré :**  je fais   
**return :**  mon travail 

### URL

un lien trop cool [ici](https://www.flaticon.com/search?word=equal)

